## Music Player

Creating beautiful UI to play music stored in the "music folder" using the HTML5 audio API

## Project Specifications

- Creating UI for music player including spinning image and song detail popup
- Adding play and pause functionality
- Switching songs
- Progress bar
